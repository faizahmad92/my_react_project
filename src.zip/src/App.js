
// import React, { useState } from 'react';
import React, { useEffect, useState } from 'react';
import './App.css';
// import { useEffect, useState } from 'react';



 import { Pool } from 'pg';
 const pool = new Pool({
   user: 'postgres',
   host: '127.0.0.1',
   database: 'movie_db',
   password: 'abc123',
   port: 5432,
 });




const movieReviews = [
  {
    id: 1,
    title: 'Guardians of the Galaxy 3',
    rating: 4.9,
    review: 'An epic space adventure with a perfect blend of action, humor, and emotion.',
    reviewer: 'Sci-Fi Enthusiast',
  },
  {
    id: 2,
    title: 'John Wick 4',
    rating: 4.7,
    review: 'Another thrilling chapter in the John Wick series with intense action sequences.',
    reviewer: 'Action Movie Fan',
  },
  {
    id: 3,
    title: 'Mario Boros',
    rating: 4.5,
    review: 'Plumber come rescue princess from evil tortoise.',
    reviewer: 'Action Movie Fan',
  },
  // Add more movie reviews here
];

const MainPage = () => {
  const [activeTab, setActiveTab] = useState('Trending');
  // const [movieData, setMovieData] = useState([]);

  // const fetchData = async () => {
  //   try {
  //     const client = await pool.connect();
  //     const result = await client.query('SELECT * FROM movies');
  //     setMovieData(result.rows); // Update the state with the fetched data
  //     client.release();
  //   } catch (error) {
  //     console.error('Error executing query:', error);
  //   }
  // };

  // const connectToDatabase = async () => {
  //   try {
  //     await pool.connect();
  //     console.log('Connected to database successfully!');
  //     fetchData(); // Once connected, fetch the data
  //   } catch (error) {
  //     console.error('Error connecting to database:', error);
  //   }
  // };

  // useEffect(() => {
  //   connectToDatabase();
  // }, []);

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  const renderMovieReviews = () => {
    if (activeTab === 'Trending') {
      return (
        <div className="movie-review-list">
          {movieReviews.map((review) => (
            <div className="movie-review" key={review.id}>
              <h2>{review.title}</h2>
              <p>Rating: {review.rating}</p>
              <p>{review.review}</p>
              <p>Reviewed by: {review.reviewer}</p>
            </div>
          ))}
        </div>
      );
    } else if (activeTab === 'Best Rated') {
      // Add code to filter and render best rated movie reviews
      return <p>Best rated movies</p>;
    } else if (activeTab === 'New Movies') {
      // Add code to filter and render new movies
      return <p>New movies</p>;
    } else {
      return null;
    }
  };

  return (
    <div className="main-page">
      <header className="header">
        <h1 className="title">Movie Review</h1>
        <div className="user-actions">
          <button className="login-button">Login</button>
          <button className="create-user-button">Create User</button>
        </div>
      </header>
      <div className="tabs">
        <button
          className={`tab ${activeTab === 'Trending' ? 'active' : ''}`}
          onClick={() => handleTabChange('Trending')}
        >
          Trending
        </button>
        <button
          className={`tab ${activeTab === 'Best Rated' ? 'active' : ''}`}
          onClick={() => handleTabChange('Best Rated')}
        >
          Best Rated
        </button>
        <button
          className={`tab ${activeTab === 'New Movies' ? 'active' : ''}`}
          onClick={() => handleTabChange('New Movies')}
        >
          New Movies
        </button>
      </div>
      <div className="main-content">{renderMovieReviews()}</div>
    </div>
  );
};

export default MainPage;
