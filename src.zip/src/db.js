const { Pool } = require('pg');

const pool = new Pool({
  user: 'postgres',
  host: '127.0.0.1',
  database: 'movie_db',
  password: 'abc123',
  port: 5432,
});

module.exports = pool;


// const express = require('express');
// const { Pool } = require('pg');

// const app = express();

// const pool = new Pool({
//   user: 'root',
//     host: '127.0.0.1',
//     database: 'movie_db',
//     password: 'abc123',
//   port: 5432, // Default PostgreSQL port
// });

// // Test the database connection
// pool.query('SELECT NOW()', (err, res) => {
//   if (err) {
//     console.error('Error connecting to the database:', err);
//   } else {
//     console.log('Connected to the database:', res.rows[0].now);
//   }
// });

// // Define your API routes and endpoints here

// app.listen(5000, () => {
//   console.log('Server is running on port 5000');
// });
